"""
Logger Usage Examples - Production Scenarios
展示如何在实际项目中使用优化后的Logger类
"""
from pathlib import Path

from lntools.utils.log import LogConfig, Logger


# ============================================================
# Scenario 1: Simple Console Logging (开发环境)
# ============================================================
def example_simple_console() -> Logger:
    """最简单的使用方式：控制台输出"""
    log = Logger("dev_app")
    log.info("Application started")
    log.debug("This won't show (default level=info)")
    return log


# ============================================================
# Scenario 2: Production File + Console Logging (生产环境)
# ============================================================
def example_production_logging() -> Logger:
    """生产环境：同时输出到文件和控制台"""
    log = Logger(
        module_name="prod_app",
        output_method=["console", "file"],
        file="/var/log/myapp/application.log",  # 指定日志路径
        level="warning"  # 生产环境只记录warning及以上
    )

    log.info("This won't show in console (level=warning)")
    log.warning("Resource usage high")
    log.error("Database connection failed")
    return log


# ============================================================
# Scenario 3: Centralized Configuration (统一配置多个模块)
# ============================================================
def example_centralized_config() -> tuple[Logger, Logger, Logger]:
    """为整个项目定义统一的日志配置"""

    # 定义项目级别的日志配置
    project_log_config: LogConfig = LogConfig(
        datetime_format='%Y-%m-%d %H:%M:%S.%f',
        file_format='[%(asctime)s][PID:%(process)d][%(name)s][%(levelname)s] %(message)s',
        console_format='%(levelname)-8s | %(name)-15s | %(message)s',
        rich_format='[bold cyan]%(name)s[/bold cyan] | %(message)s',
        default_level='info',
        default_output_method=['console', 'file'],
        default_rich=True,
        default_log_dir=Path('/var/log/trading_system')
    )

    # 各模块使用相同配置
    strategy_log = Logger("strategy_engine", config=project_log_config)
    execution_log = Logger("execution_engine", config=project_log_config)
    risk_log = Logger("risk_manager", config=project_log_config)

    strategy_log.info("Strategy initialized")
    execution_log.info("Order execution started")
    risk_log.warning("Position limit approaching")

    return strategy_log, execution_log, risk_log


# ============================================================
# Scenario 4: High-Frequency Trading System (高频交易系统)
# ============================================================
def example_hft_system() -> tuple[Logger, Logger, Logger]:
    """高频交易系统：性能优先，禁用rich格式"""

    hft_config = LogConfig(
        datetime_format='%Y%m%d %H:%M:%S.%f',  # 紧凑格式
        console_format='%(asctime)s|%(levelname)s|%(name)s|%(message)s',
        file_format='%(asctime)s|%(levelname)s|%(name)s|%(message)s',
        default_rich=False,  # 禁用rich以提升性能
        default_level='warning',  # 只记录重要信息
        default_log_dir=Path('/data/hft_logs')
    )

    tick_log = Logger("tick_data", config=hft_config, level='error')  # tick数据只记录错误
    signal_log = Logger("signal_gen", config=hft_config, level='info')
    order_log = Logger("order_exec", config=hft_config, level='warning')

    # 高频场景下的日志
    signal_log.info("Signal generated: BUY AAPL @ 150.25")
    order_log.warning("Order rejected: insufficient margin")

    return tick_log, signal_log, order_log


# ============================================================
# Scenario 5: Dynamic Handler Management (动态添加监控)
# ============================================================
def example_dynamic_monitoring() -> Logger:
    """运行时动态添加监控handler（如Syslog, Email等）"""
    import logging
    from logging.handlers import SysLogHandler

    log = Logger("monitored_app", output_method="console")

    # 运行时添加Syslog handler (Unix-like系统)
    try:
        syslog_handler = SysLogHandler(address='/dev/log')
        syslog_handler.setLevel(logging.ERROR)
        syslog_handler.setFormatter(
            logging.Formatter('MyApp[%(process)d]: %(levelname)s - %(message)s')
        )
        log.add_handler("syslog", syslog_handler)
        log.info("Syslog handler added")
    except Exception as e:  # pylint: disable=w0718
        log.warning(f"Failed to add syslog handler: {e}")

    # 关键错误时发送邮件（需配置SMTP）
    # email_handler = SMTPHandler(
    #     mailhost=('smtp.example.com', 587),
    #     fromaddr='app@example.com',
    #     toaddrs=['admin@example.com'],
    #     subject='Critical Application Error',
    #     credentials=('user', 'password'),
    #     secure=()
    # )
    # email_handler.setLevel(logging.CRITICAL)
    # log.add_handler("email_alerts", email_handler)

    log.error("This goes to console and syslog")
    log.critical("This would also trigger email alert")

    return log


# ============================================================
# Scenario 6: Database Operations with Structured Logging
# ============================================================
def example_database_logging() -> Logger:
    """数据库操作日志：结构化记录"""

    db_config = LogConfig(
        file_format='[%(asctime)s][%(name)s][%(levelname)s][%(funcName)s:%(lineno)d] %(message)s',
        default_level='debug',
        default_log_dir=Path('./logs/database')
    )

    db_log = Logger("clickhouse_ops", config=db_config, output_method=["console", "file"])

    # 记录SQL执行
    query = "SELECT * FROM market_data WHERE dt >= '2026-01-01'"
    db_log.info(f"Executing query: {query}")

    # 记录性能指标
    execution_time_ms = 125.43
    rows_returned = 1500000
    db_log.info(f"Query completed | Time: {execution_time_ms:.2f}ms | Rows: {rows_returned}")

    # 错误处理
    try:
        # Simulated error
        raise ConnectionError("ClickHouse connection lost")
    except ConnectionError:
        db_log.exception("Database connection error occurred")

    return db_log


# ============================================================
# Scenario 7: Microservices with Module Isolation
# ============================================================
def example_microservices() -> tuple[Logger, Logger]:
    """微服务架构：每个服务独立日志"""

    # Service A的日志配置
    service_a_config = LogConfig(
        console_format='[ServiceA] %(levelname)-8s | %(message)s',
        default_log_dir=Path('./logs/service_a')
    )
    log_a = Logger("service_a", config=service_a_config)

    # Service B的日志配置（不同格式）
    service_b_config = LogConfig(
        console_format='[ServiceB] %(levelname)-8s | %(message)s',
        default_log_dir=Path('./logs/service_b')
    )
    log_b = Logger("service_b", config=service_b_config)

    log_a.info("Service A processing request ID: 12345")
    log_b.info("Service B received message from queue")

    return log_a, log_b


# ============================================================
# Scenario 8: Development vs Production Configuration
# ============================================================
def example_environment_based() -> Logger:
    """根据环境变量选择不同配置"""
    import os

    env = os.getenv("APP_ENV", "development")

    if env == "production":
        config = LogConfig(
            default_level='warning',
            default_rich=False,
            default_output_method=['file'],
            default_log_dir=Path('/var/log/production')
        )
    elif env == "staging":
        config = LogConfig(
            default_level='info',
            default_rich=True,
            default_output_method=['console', 'file'],
            default_log_dir=Path('./logs/staging')
        )
    else:  # development
        config = LogConfig(
            default_level='debug',
            default_rich=True,
            default_output_method=['console']
        )

    log = Logger("app", config=config)
    log.debug("Running in %s mode", env)
    return log


# ============================================================
# Scenario 9: Custom Handler for Metrics Collection
# ============================================================
def example_metrics_collection() -> Logger:
    """自定义handler收集日志指标"""
    from collections import defaultdict
    import logging

    class MetricsHandler(logging.Handler):
        """统计各级别日志数量"""
        def __init__(self) -> None:
            super().__init__()
            self.counts: defaultdict[str, int] = defaultdict(int)

        def emit(self, record: logging.LogRecord) -> None:
            self.counts[record.levelname] += 1

        def get_metrics(self) -> dict[str, int]:
            return dict(self.counts)

    log = Logger("metrics_app", output_method="console")

    # 添加指标收集handler
    metrics_handler = MetricsHandler()
    log.add_handler("metrics", metrics_handler)

    # 生成一些日志
    log.info("User login successful")
    log.warning("Slow query detected")
    log.error("Payment processing failed")
    log.info("User logout")
    log.error("API timeout")

    # 获取指标
    metrics = metrics_handler.get_metrics()
    print(f"\nLog Metrics: {metrics}")
    # Output: {'INFO': 2, 'WARNING': 1, 'ERROR': 2}

    return log


# ============================================================
# Main Demo
# ============================================================
if __name__ == "__main__":
    print("\n" + "=" * 70)
    print("LOGGER USAGE EXAMPLES - PRODUCTION SCENARIOS")
    print("=" * 70 + "\n")

    scenarios = [
        ("Simple Console Logging", example_simple_console),
        ("Production Logging", example_production_logging),
        ("Centralized Configuration", example_centralized_config),
        ("High-Frequency Trading", example_hft_system),
        ("Dynamic Monitoring", example_dynamic_monitoring),
        ("Database Operations", example_database_logging),
        ("Microservices", example_microservices),
        ("Environment-Based Config", example_environment_based),
        ("Metrics Collection", example_metrics_collection),
    ]

    for name, func in scenarios:
        print(f"\n{'─' * 70}")
        print(f"Scenario: {name}")
        print('─' * 70)
        try:
            func()
        except Exception as e:  # pylint: disable=w0718
            print(f"Error in {name}: {e}")

    print("\n" + "=" * 70)
    print("ALL SCENARIOS COMPLETED")
    print("=" * 70)
