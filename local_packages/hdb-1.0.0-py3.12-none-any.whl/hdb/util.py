
import numpy as np
import pandas as pd 



__all__ = [
    'dataframe_decode',
    'convert_hdbframe_to_pandasframe',
    'convert_hdbframe_to_numpy'
]

def dataframe_decode(df, decoding ="GBK"):
    str_df = df.select_dtypes([object])
    str_df = str_df.stack().str.decode(decoding).unstack()
    for col in str_df:
        df[col] = str_df[col]
        
def convert_hdbframe_to_pandasframe(frame, fields , in_place = False):
    if len(frame.data) == 0:
        return pd.DataFrame()
    df = pd.DataFrame(np.array([np.array(v, copy=~in_place) for v in frame.data]).T, columns = fields)
    return df
    
def convert_hdbframe_to_numpy(frame, in_place = False):
    if len(frame.data) == 0:
        return np.array([])
    return np.array([np.array(v, copy=~in_place) for v in frame.data]).T
