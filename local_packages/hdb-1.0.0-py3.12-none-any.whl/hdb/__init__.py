from .pyhdb import *
from contextlib import contextmanager
#import numpy as np
#import pandas as pd
from . import util
#from .pyhdb import (
#
#    ReadTask, DB
#)

__all__ = ['ReadTask', 'File', 'DB', 'Client', 'calc_tradetime_offset', 'DataFrame', 'Codetable', 'DataType', 'DataField', 'FieldFlag', 'FieldType', 'ClientReadTaskOption'
            'open_file', 'dataframe_decode_in_Chinese', 'convert_hdbframe_to_pandasframe', 'convert_hdbframe_to_nparray']

@contextmanager
def open_file(db, file_path, mode):
    f = db.open_file(file_path, mode)
    yield f
    f.close()
    

