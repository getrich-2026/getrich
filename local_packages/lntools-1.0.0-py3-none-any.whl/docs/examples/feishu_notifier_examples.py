"""
FeishuNotifier Usage Examples

This module demonstrates various ways to send notifications using FeishuNotifier.

Author: Neo
Date: 2026-01-13
"""
from __future__ import annotations

import time

from lntools.bot.notify import FeishuNotifier

# ============================================
# Configuration
# ============================================

WEBHOOK_URL = "https://open.feishu.cn/open-apis/bot/v2/hook/a8288a19-4973-4c54-9825-ee0e223cfb93"


# ============================================
# Example 1: Basic Text Message
# ============================================

def example_text_simple():
    """Send simple text message."""
    print("\n=== Example 1: Simple Text Message ===")

    notifier = FeishuNotifier(webhook=WEBHOOK_URL)

    success = notifier.send_text("Hello from lntools! 🚀")

    if success:
        print("✓ Message sent successfully")
    else:
        print("✗ Failed to send message")


# ============================================
# Example 2: Text with @mentions
# ============================================

def example_text_with_mentions():
    """Send text message with user mentions."""
    print("\n=== Example 2: Text with @mentions ===")

    notifier = FeishuNotifier(webhook=WEBHOOK_URL)

    # Mention specific users by user_id
    success = notifier.send_text(
        message="Task completed! Please review.",
        mentioned_list=["ou_xxxx", "ou_yyyy"]  # Replace with actual user IDs
    )

    # Mention all users
    success = notifier.send_text(
        message="System maintenance in 10 minutes",
        mentioned_list=["all"]
    )

    print(f"Notification sent: {success}")


# ============================================
# Example 3: Interactive Card - Simple
# ============================================

def example_card_simple():
    """Send simple interactive card."""
    print("\n=== Example 3: Simple Interactive Card ===")

    notifier = FeishuNotifier(webhook=WEBHOOK_URL)

    success = notifier.send_card(
        title="Daily Report",
        content="**Date**: 2026-01-13\n**Status**: ✅ All systems operational\n**Uptime**: 99.9%",
        theme="green"
    )

    print(f"Card sent: {success}")


# ============================================
# Example 4: Card with Different Themes
# ============================================

def example_card_themes():
    """Demonstrate different card theme colors."""
    print("\n=== Example 4: Card Themes ===")

    notifier = FeishuNotifier(webhook=WEBHOOK_URL)

    themes = [
        ("blue", "Info", "This is an informational message"),
        ("green", "Success", "✅ Operation completed successfully"),
        ("yellow", "Warning", "⚠️ High memory usage detected"),
        ("red", "Error", "❌ Critical: Database connection failed"),
        ("purple", "Update", "📦 New version available: v2.1.0"),
    ]

    for theme, title, content in themes:
        notifier.send_card(title=title, content=content, theme=theme)
        time.sleep(1)  # Avoid rate limiting

    print("All themed cards sent")


# ============================================
# Example 5: Rich Text (Post) Message
# ============================================

def example_post_message():
    """Send rich text post message."""
    print("\n=== Example 5: Rich Text Post ===")

    notifier = FeishuNotifier(webhook=WEBHOOK_URL)

    post_content = {
        "zh_cn": {
            "title": "Quantitative Trading Report",
            "content": [
                [
                    {"tag": "text", "text": "Strategy: "},
                    {"tag": "text", "text": "Mean Reversion v3.2"},
                ],
                [
                    {"tag": "text", "text": "Performance: "},
                    {"tag": "text", "text": "+15.8%"},
                ],
                [
                    {"tag": "a", "text": "📊 View Full Report", "href": "https://example.com/report"},
                ],
                [
                    {"tag": "text", "text": "Generated at: 2026-01-13 10:30:00"},
                ],
            ],
        }
    }

    success = notifier.send("post", post_content)
    print(f"Rich text post sent: {success}")


# ============================================
# Example 6: Advanced Card with Multiple Elements
# ============================================

def example_advanced_card():
    """Send advanced interactive card with multiple elements."""
    print("\n=== Example 6: Advanced Interactive Card ===")

    notifier = FeishuNotifier(webhook=WEBHOOK_URL)

    card_data = {
        "config": {"enable_forward": True},
        "header": {
            "template": "blue",
            "title": {"content": "System Monitoring Alert", "tag": "plain_text"},
        },
        "elements": [
            {
                "tag": "div",
                "text": {
                    "content": "**Alert Level**: P1\n**Service**: trading-engine\n**Time**: 2026-01-13 10:00:00",
                    "tag": "lark_md",
                },
            },
            {"tag": "hr"},
            {
                "tag": "div",
                "fields": [
                    {"is_short": True, "text": {"content": "**CPU**\n95%", "tag": "lark_md"}},
                    {"is_short": True, "text": {"content": "**Memory**\n8.2 GB", "tag": "lark_md"}},
                    {"is_short": True, "text": {"content": "**Disk**\n45%", "tag": "lark_md"}},
                    {"is_short": True, "text": {"content": "**Network**\n150 Mbps", "tag": "lark_md"}},
                ],
            },
            {"tag": "hr"},
            {
                "tag": "action",
                "actions": [
                    {
                        "tag": "button",
                        "text": {"content": "View Details", "tag": "plain_text"},
                        "type": "primary",
                        "url": "https://example.com/alerts/12345",
                    },
                    {
                        "tag": "button",
                        "text": {"content": "Acknowledge", "tag": "plain_text"},
                        "type": "default",
                        "url": "https://example.com/ack/12345",
                    },
                ],
            },
        ],
    }

    success = notifier.send("interactive", card_data)
    print(f"Advanced card sent: {success}")


# ============================================
# Example 7: Error Handling
# ============================================

def example_error_handling():
    """Demonstrate error handling patterns."""
    print("\n=== Example 7: Error Handling ===")

    # Invalid webhook
    notifier = FeishuNotifier(webhook="https://invalid-webhook-url.com")

    try:
        success = notifier.send_text("Test message")
        if not success:
            print("✗ Failed to send (expected, invalid webhook)")
    except Exception as e:  # pylint: disable=broad-except
        print(f"Exception caught: {e}")

    # Message too long
    notifier = FeishuNotifier(webhook=WEBHOOK_URL)
    long_message = "A" * 3000  # Exceeds 2048 bytes

    success = notifier.send_text(long_message)
    print(f"Long message sent: {success} (warning should be logged)")


# ============================================
# Example 8: Custom Retry Configuration
# ============================================

def example_custom_retry():
    """Configure custom retry behavior."""
    print("\n=== Example 8: Custom Retry Configuration ===")

    # High retry for critical notifications
    notifier = FeishuNotifier(
        webhook=WEBHOOK_URL,
        timeout=15,  # Longer timeout
        retries=5,   # More retries
    )

    success = notifier.send_text("Critical: Payment processing failed")
    print(f"Critical notification sent: {success}")


# ============================================
# Example 9: Batch Notifications
# ============================================

def example_batch_notifications():
    """Send multiple notifications efficiently."""
    print("\n=== Example 9: Batch Notifications ===")

    import requests

    # Reuse session for better performance
    session = requests.Session()
    notifier = FeishuNotifier(webhook=WEBHOOK_URL, session=session)

    messages = [
        ("Info", "System startup completed", "blue"),
        ("Success", "Data sync finished", "green"),
        ("Update", "Cache cleared", "purple"),
    ]

    for title, content, theme in messages:
        notifier.send_card(title=title, content=content, theme=theme)
        time.sleep(0.5)  # Rate limiting

    session.close()
    print("Batch notifications sent")


# ============================================
# Example 10: Real-world Use Case - Trading Alert
# ============================================

def example_trading_alert():
    """Real-world example: Trading system alert."""
    print("\n=== Example 10: Trading Alert ===")

    notifier = FeishuNotifier(webhook=WEBHOOK_URL)

    # Simulated trading data
    strategy = "MeanReversion_v2"
    symbol = "AAPL"
    action = "BUY"
    price = 185.50
    quantity = 100
    pnl = 1250.00

    card_content = f"""**Strategy**: {strategy}
**Symbol**: {symbol}
**Action**: {action}
**Price**: ${price:.2f}
**Quantity**: {quantity}
**Estimated P&L**: ${pnl:,.2f}

<at id=all></at>
    """

    success = notifier.send_card(
        title=f"🚨 Trading Signal: {action} {symbol}",
        content=card_content,
        theme="orange"
    )

    print(f"Trading alert sent: {success}")


# ============================================
# Example 11: Multi-language Post
# ============================================

def example_multilingual_post():
    """Send post message with multiple languages."""
    print("\n=== Example 11: Multi-language Post ===")

    notifier = FeishuNotifier(webhook=WEBHOOK_URL)

    post_content = {
        "zh_cn": {
            "title": "系统升级通知",
            "content": [
                [{"tag": "text", "text": "系统将于今晚 22:00 进行升级维护"}],
                [{"tag": "text", "text": "预计耗时：2小时"}],
            ],
        },
        "en_us": {
            "title": "System Upgrade Notice",
            "content": [
                [{"tag": "text", "text": "System maintenance scheduled at 22:00 tonight"}],
                [{"tag": "text", "text": "Estimated duration: 2 hours"}],
            ],
        },
    }

    success = notifier.send("post", post_content)
    print(f"Multi-language post sent: {success}")


# ============================================
# Main Execution
# ============================================

if __name__ == "__main__":
    print("=" * 60)
    print("FeishuNotifier Examples")
    print("=" * 60)

    # IMPORTANT: Replace WEBHOOK_URL with your actual webhook URL before running
    if "YOUR_WEBHOOK_TOKEN" in WEBHOOK_URL:
        print("\n⚠️  Please configure WEBHOOK_URL before running examples")
        print("Get your webhook URL from: https://open.feishu.cn/")
    else:
        # Run all examples
        # example_text_simple()
        # example_text_with_mentions()
        # example_card_simple()
        # example_card_themes()
        # example_post_message()
        # example_advanced_card()
        # example_error_handling()
        # example_custom_retry()
        # example_batch_notifications()
        # example_trading_alert()
        example_multilingual_post()

        print("\n" + "=" * 60)
        print("All examples completed!")
        print("=" * 60)
