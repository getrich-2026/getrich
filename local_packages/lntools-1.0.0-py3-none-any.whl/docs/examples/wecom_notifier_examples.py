"""
Test script for WeComNotifier class.
Tests various message types and features.
"""
from __future__ import annotations

from lntools.bot import WeComNotifier

WEBHOOK = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=84d4d853-0cd9-44ed-9183-20ed5145dd5d"


def wecom_basic_text():
    """Test basic text message."""
    print("=" * 60)
    print("Test 1: Basic Text Message")
    print("=" * 60)

    # 替换为你的企业微信 Webhook URL
    wecom = WeComNotifier(WEBHOOK)

    # 基础文本消息
    success = wecom.send_text("Test message from lntools")
    print(f"Send result: {success}")
    print()


def wecom_text_with_mention():
    """Test text message with @mention."""
    print("=" * 60)
    print("Test 2: Text with @Mention")
    print("=" * 60)

    wecom = WeComNotifier(WEBHOOK)

    # @提醒所有人
    success = wecom.send_text(
        "Critical alert: System overload detected!",
        mentioned_list=["@all"]
    )
    print(f"Send result: {success}")
    print()


def wecom_markdown():
    """Test Markdown formatted message."""
    print("=" * 60)
    print("Test 3: Markdown Message")
    print("=" * 60)

    wecom = WeComNotifier(WEBHOOK)

    markdown_msg = """
    # 📊 Daily Trading Report
    **Date**: 2026-01-13
    **Status**: <font color="info">Success</font>

    ## Performance Metrics
    - Total Trades: **156**
    - Win Rate: **68.5%**
    - Profit/Loss: **+$12,450**
    - Sharpe Ratio: **2.34**

    ## Top Performers
    1. AAPL: +3.2%
    2. GOOGL: +2.8%
    3. MSFT: +2.1%

    > [View Detailed Report](https://example.com/reports/20260113)
    """

    success = wecom.send_markdown(markdown_msg)
    print(f"Send result: {success}")
    print()


def wecom_news():
    """Test news (rich media) message."""
    print("=" * 60)
    print("Test 4: News Message")
    print("=" * 60)

    wecom = WeComNotifier(WEBHOOK)

    articles = [
        {
            "title": "Market Analysis: Q1 2026 Review",
            "description": "Comprehensive quarterly market analysis and trends",
            "url": "https://example.com/analysis/q1-2026",
            "picurl": "https://via.placeholder.com/400x300/4A90E2/ffffff?text=Market+Chart"
        },
        {
            "title": "New Trading Strategy Deployed",
            "description": "Momentum-based strategy v2.0 now live",
            "url": "https://example.com/strategy/momentum-v2",
            "picurl": "https://via.placeholder.com/400x300/50E3C2/ffffff?text=Strategy"
        },
        {
            "title": "System Upgrade Notice",
            "url": "https://example.com/notices/upgrade"
        }
    ]

    success = wecom.send_news(articles)
    print(f"Send result: {success}")
    print()


def wecom_simple_card():
    """Test simplified text notice card."""
    print("=" * 60)
    print("Test 5: Simplified Text Notice Card")
    print("=" * 60)

    wecom = WeComNotifier(WEBHOOK)

    success = wecom.send_text_notice_card(
        title="Backtest Completed",
        description="Strategy backtest finished successfully",
        emphasis_title="18.5%",
        emphasis_desc="Annual Return",
        url="https://example.com/backtest/12345",
        fields=[
            {"keyname": "Strategy", "value": "Momentum V2"},
            {"keyname": "Period", "value": "2023-2025"},
            {"keyname": "Sharpe", "value": "2.45"},
            {"keyname": "Max DD", "value": "-12.3%"},
            {"keyname": "Win Rate", "value": "71.2%"}
        ]
    )
    print(f"Send result: {success}")
    print()


def wecom_advanced_card():
    """Test advanced template card with full configuration."""
    print("=" * 60)
    print("Test 6: Advanced Template Card")
    print("=" * 60)

    wecom = WeComNotifier(WEBHOOK)

    card_data = {
        "source": {
            "icon_url": "https://via.placeholder.com/50/FF6B6B/ffffff?text=!",
            "desc": "Risk Management System"
        },
        "main_title": {
            "title": "Position Limit Alert",
            "desc": "AAPL position approaching maximum limit"
        },
        "emphasis_content": {
            "title": "95%",
            "desc": "of Max Position"
        },
        "sub_title_text": "2026-01-13 15:45:30",
        "horizontal_content_list": [
            {"keyname": "Symbol", "value": "AAPL"},
            {"keyname": "Current", "value": "47,500 shares"},
            {"keyname": "Limit", "value": "50,000 shares"},
            {"keyname": "Action", "value": "Review Required"}
        ],
        "card_action": {
            "type": 1,
            "url": "https://example.com/risk/alerts/67890"
        }
    }

    success = wecom.send_template_card("text_notice", card_data)
    print(f"Send result: {success}")
    print()


def wecom_error_handling():
    """Test error handling."""
    print("=" * 60)
    print("Test 7: Error Handling")
    print("=" * 60)

    # 使用无效的webhook测试错误处理
    invalid_webhook = "https://invalid.webhook.url"
    wecom = WeComNotifier(invalid_webhook, retries=2, timeout=5)

    print(f"WeComNotifier instance: {repr(wecom)}")

    success = wecom.send_text("This should fail")
    print(f"Expected failure result: {success}")
    print()


def wecom_repr():
    """Test __repr__ method."""
    print("=" * 60)
    print("Test 8: String Representation")
    print("=" * 60)

    wecom = WeComNotifier(WEBHOOK, timeout=15, retries=5)

    print(f"Instance repr: {repr(wecom)}")
    print()


def wecom_usage_examples():
    """Show practical usage examples."""
    print("\n" + "=" * 60)
    print("USAGE EXAMPLES")
    print("=" * 60 + "\n")

    wecom = WeComNotifier(WEBHOOK)

    # Example 1: Data pipeline notification
    print("Example 1: Data Pipeline Notification")
    print("-" * 60)
    markdown = """
    # Data Pipeline Completed
    **Pipeline**: ETL_Daily_Market_Data
    **Status**: ✅ Success

    ## Statistics
    - Records Inserted: **1,245,678**
    - Processing Time: **3 min 42 sec**
    - Data Quality Score: **99.7%**
    """
    wecom.send_markdown(markdown)
    print("Sent: Data pipeline notification\n")

    # Example 2: Trading signal alert
    print("Example 2: Trading Signal Alert")
    print("-" * 60)
    wecom.send_text_notice_card(
        title="New Trading Signal",
        description="Strong momentum detected",
        emphasis_title="BUY",
        emphasis_desc="AAPL",
        fields=[
            {"keyname": "Signal Strength", "value": "8.5/10"},
            {"keyname": "Entry Price", "value": "$175.50"},
            {"keyname": "Target", "value": "$185.00"},
            {"keyname": "Stop Loss", "value": "$170.00"}
        ],
        url="https://example.com/signals/20260113-001"
    )
    print("Sent: Trading signal alert\n")

    # Example 3: System monitoring
    print("Example 3: System Monitoring Alert")
    print("-" * 60)
    wecom.send_text(
        "⚠️ High CPU usage detected on trading-server-01\nCPU: 92%, Memory: 78%\nPlease investigate",
        mentioned_list=["@all"]
    )
    print("Sent: System monitoring alert\n")


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("WECOM NOTIFIER TEST SUITE")
    print("=" * 60 + "\n")

    print("NOTE: Replace 'YOUR-KEY' with actual webhook key to test\n")

    # 运行测试（需要替换真实的webhook才能成功）
    # wecom_basic_text()
    # wecom_text_with_mention()
    # wecom_markdown()
    # wecom_news()
    # wecom_simple_card()
    # wecom_advanced_card()
    wecom_error_handling()
    wecom_repr()

    # 显示使用示例
    wecom_usage_examples()

    print("=" * 60)
    print("TEST SUITE COMPLETED")
    print("=" * 60)
    print("\nKey Features:")
    print("✓ Text messages with @mention support")
    print("✓ Markdown formatted messages")
    print("✓ Image messages (base64 + md5)")
    print("✓ News (rich media) messages")
    print("✓ File messages (via media_id)")
    print("✓ Template cards (text_notice/news_notice)")
    print("✓ Simplified card helper method")
    print("✓ Automatic retry with exponential backoff")
    print("✓ Comprehensive error handling")
    print("✓ Production-ready logging")
