from concurrent.futures import ThreadPoolExecutor
import time

from lntools.utils.human import RichProgressManager, track_simple


def demo_tqdm_simple():
    print("\n=== 演示 1: 使用 track_simple (tqdm) ===")
    data = range(50)
    results = []
    # 模拟 tqdm 可用
    for i in track_simple(data, msg="数据预处理"):
        time.sleep(0.02)
        results.append(i)
    print("tqdm 演示完成。")


def demo_rich_nested():
    print("\n=== 演示 2: Rich 嵌套循环 (多进度条) ===")

    with RichProgressManager() as rpm:
        epochs = 3
        for epoch in rpm.track(epochs, msg="[bold green]Epochs"):
            batches = 20
            for _ in rpm.track(batches, msg=f"  Batch {epoch}"):
                time.sleep(0.05)


def demo_rich_parallel():
    print("\n=== 演示 3: Rich 多线程并行 (真正的多任务) ===")

    def worker(job_id: int, manager: RichProgressManager):
        total_steps = 50
        delay = 0.05 + (job_id * 0.01)

        # 演示任务完成后移除进度条的效果
        for _ in manager.track(total_steps, msg=f"[cyan]Worker-{job_id} downloading"):
            time.sleep(delay)

    # 开启 remove_task_on_finish=True，看下动态移除效果
    with RichProgressManager(remove_task_on_finish=True) as rpm, ThreadPoolExecutor(max_workers=4) as executor:
        futures = [executor.submit(worker, i, rpm) for i in range(1, 5)]
        for f in futures:
            f.result()


if __name__ == "__main__":
    try:
        demo_tqdm_simple()
        time.sleep(1)

        demo_rich_nested()
        time.sleep(1)

        demo_rich_parallel()

    except KeyboardInterrupt:
        print("\nDemo interrupted.")
